package org.example.notifyservice.consumer;

import org.example.notifyservice.service.EmailService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketCreatedConsumerTest {

    @Mock
    private EmailService emailService;

    @InjectMocks
    private TicketCreatedConsumer consumer;

    @Test
    void consume_WhenValidEmail_ShouldCallEmailService() {
        consumer.consume("customer@example.com");

        verify(emailService, times(1)).sendOrderCreatedEmail("customer@example.com");
    }

    @Test
    void consume_WhenEmailHasWhitespace_ShouldTrimAndCallEmailService() {
        consumer.consume("  customer@example.com  ");

        verify(emailService, times(1)).sendOrderCreatedEmail("customer@example.com");
    }

    @Test
    void consume_WhenNullOrEmptyEmail_ShouldNotCallEmailService() {
        consumer.consume(null);
        consumer.consume("");
        consumer.consume("   ");

        verifyNoInteractions(emailService);
    }
}
