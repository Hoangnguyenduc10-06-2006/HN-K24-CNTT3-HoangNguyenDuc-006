package org.example.ticketservice.models.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.ticketservice.models.constants.TicketStatus;
import org.example.ticketservice.models.dto.requests.CreateTicketDetailRequest;
import org.example.ticketservice.models.dto.requests.CreateTicketRequest;
import org.example.ticketservice.models.dto.responses.TicketDetailResponse;
import org.example.ticketservice.models.dto.responses.TicketResponse;
import org.example.ticketservice.models.dto.responses.TripResponse;
import org.example.ticketservice.models.entities.Ticket;
import org.example.ticketservice.models.entities.TicketDetail;
import org.example.ticketservice.models.repositories.TicketDetailRepository;
import org.example.ticketservice.models.repositories.TicketRepository;
import org.example.ticketservice.models.services.TicketService;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class TicketServiceImpl implements TicketService {
    private final TicketRepository ticketRepository;
    private final TicketDetailRepository ticketDetailRepository;
    private final TripGatewayService tripGatewayService;
    private final KafkaTemplate<String, String> kafkaTemplate;

    @Override
    @Transactional(readOnly = true)
    public Long getTicketId(Long id) {
        return ticketRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ticket not found with id: " + id))
                .getId();
    }

    @Override
    @Transactional
    public TicketResponse createTicket(CreateTicketRequest request) {
        if (request == null || request.items() == null || request.items().isEmpty()) {
            throw new IllegalArgumentException("Ticket must contain at least one item");
        }

        double totalAmount = 0.0;

        record DetailItemData(CreateTicketDetailRequest requestItem, TripResponse trip, double lineTotal) {}
        List<DetailItemData> itemDataList = new ArrayList<>();

        for (CreateTicketDetailRequest item : request.items()) {
            if (item.seat() == null || item.seat() <= 0) {
                throw new IllegalArgumentException("Seats must be greater than 0");
            }

            TripResponse trip = tripGatewayService.getTripById(item.tripId());

            if (trip.availableSeats() == null || item.seat() > trip.availableSeats()) {
                throw new IllegalArgumentException("Not enough available seats for trip ID: " + item.tripId()
                        + ". Requested: " + item.seat() + ", Available: " + (trip.availableSeats() != null ? trip.availableSeats() : 0));
            }

            Double ticketPrice = trip.ticketPrice() != null ? trip.ticketPrice() : 0.0;
            double lineTotal = ticketPrice * item.seat();
            totalAmount += lineTotal;

            itemDataList.add(new DetailItemData(item, trip, lineTotal));
        }

        Ticket ticket = Ticket.builder()
                .passengerName(request.passengerName())
                .passengerEmail(request.passengerEmail())
                .totalAmount(totalAmount)
                .status(TicketStatus.PENDING)
                .build();
        Ticket savedTicket = ticketRepository.save(ticket);

        List<TicketDetail> detailsToSave = new ArrayList<>();
        for (DetailItemData itemData : itemDataList) {
            TicketDetail detail = TicketDetail.builder()
                    .ticket(savedTicket)
                    .tripId(itemData.trip().id())
                    .seats(itemData.requestItem().seat())
                    .ticketPrice(itemData.trip().ticketPrice())
                    .lineTotal(itemData.lineTotal())
                    .build();
            detailsToSave.add(detail);
        }
        List<TicketDetail> savedDetails = ticketDetailRepository.saveAll(detailsToSave);

        List<TicketDetailResponse> detailResponses = savedDetails.stream()
                .map(detail -> new TicketDetailResponse(
                        detail.getId(),
                        detail.getTripId(),
                        detail.getSeats(),
                        detail.getTicketPrice(),
                        detail.getLineTotal()
                ))
                .toList();

        TicketResponse response = new TicketResponse(
                savedTicket.getId(),
                savedTicket.getPassengerName(),
                savedTicket.getPassengerEmail(),
                savedTicket.getTotalAmount(),
                savedTicket.getStatus(),
                detailResponses
        );

        try {
            kafkaTemplate.send("ticket-created", savedTicket.getPassengerEmail());
            log.info("Sent Kafka message to topic ticket-created for email: {}", savedTicket.getPassengerEmail());
        } catch (Exception e) {
            log.error("Failed to send Kafka message to topic ticket-created: {}", e.getMessage(), e);
            throw e;
        }

        return response;
    }
}
