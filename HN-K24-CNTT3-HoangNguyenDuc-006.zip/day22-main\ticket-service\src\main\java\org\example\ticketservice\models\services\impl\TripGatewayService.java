package org.example.ticketservice.models.services.impl;

import feign.FeignException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.ticketservice.clients.TripClient;
import org.example.ticketservice.exceptions.TripNotFoundException;
import org.example.ticketservice.exceptions.TripServiceException;
import org.example.ticketservice.models.dto.responses.TripResponse;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class TripGatewayService {

    private final TripClient tripClient;

    @CircuitBreaker(name = "tripService", fallbackMethod = "getTripByIdFallback")
    public TripResponse getTripById(Long tripId) {
        try {
            TripResponse response = tripClient.getTripById(tripId);
            if (response == null || response.id() == null) {
                throw new TripNotFoundException(tripId);
            }
            return response;
        } catch (FeignException.NotFound e) {
            throw new TripNotFoundException(tripId);
        } catch (FeignException e) {
            if (e.status() == 404) {
                throw new TripNotFoundException(tripId);
            }
            throw new TripServiceException("Error from Trip Service: " + e.getMessage(), e);
        }
    }

    public TripResponse getTripByIdFallback(Long tripId, Throwable throwable) {
        log.error("Fallback called for trip id {}: {}", tripId, throwable.getMessage());
        if (throwable instanceof TripNotFoundException tripNotFound) {
            throw tripNotFound;
        }
        if (throwable instanceof FeignException.NotFound) {
            throw new TripNotFoundException(tripId);
        }
        if (throwable instanceof FeignException feignEx && feignEx.status() == 404) {
            throw new TripNotFoundException(tripId);
        }
        if (throwable instanceof TripServiceException tripServiceException) {
            throw tripServiceException;
        }
        throw new TripServiceException("Trip service is unavailable: " + throwable.getMessage(), throwable);
    }

}
