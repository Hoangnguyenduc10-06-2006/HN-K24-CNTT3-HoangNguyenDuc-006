package org.example.notifyservice.consumer;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.notifyservice.service.EmailService;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class TicketCreatedConsumer {
    private final EmailService emailService;

    @KafkaListener(topics = "${notification.kafka.ticket-created-topic:${notification.kafka.order-created-topic:ticket-created}}")
    public void consume(String customerEmail) {
        log.info("Received ticket created event for email: {}", customerEmail);
        if (customerEmail != null && !customerEmail.trim().isEmpty()) {
            emailService.sendOrderCreatedEmail(customerEmail.trim());
        } else {
            log.warn("Received empty or null customer email in ticket-created topic");
        }
    }
}
