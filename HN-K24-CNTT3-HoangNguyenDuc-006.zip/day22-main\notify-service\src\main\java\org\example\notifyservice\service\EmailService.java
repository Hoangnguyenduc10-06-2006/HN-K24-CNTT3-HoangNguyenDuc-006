package org.example.notifyservice.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class EmailService {
    private final JavaMailSender mailSender;
    private final String from;

    public EmailService(
            @Autowired(required = false) JavaMailSender mailSender,
            @Value("${notification.mail.from:${spring.mail.username:noreply@example.com}}") String from) {
        this.mailSender = mailSender;
        this.from = (from != null && !from.isBlank()) ? from : "noreply@example.com";
    }

    public void sendOrderCreatedEmail(String recipient) {
        if (recipient == null || recipient.trim().isEmpty()) {
            throw new IllegalArgumentException("Recipient email must not be null or empty");
        }
        JavaMailSender mailSender = this.mailSender;
        if (mailSender == null) {
            throw new UnsupportedOperationException("JavaMailSender is not configured");
        }
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setFrom(this.from);
        mailMessage.setTo(recipient.trim());
        mailMessage.setSubject("Order Created");
        mailMessage.setText("Your order has been created successfully.");
        mailSender.send(mailMessage);
        log.info("Sent order confirmation email to {}", recipient);
    }
}
