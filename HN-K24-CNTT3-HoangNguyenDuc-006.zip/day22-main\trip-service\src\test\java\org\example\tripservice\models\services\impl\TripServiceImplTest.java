package org.example.tripservice.models.services.impl;

import org.example.tripservice.exceptions.TripNotFoundException;
import org.example.tripservice.models.entities.Trip;
import org.example.tripservice.models.repositories.TripRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.annotation.Cacheable;

import java.lang.reflect.Method;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TripServiceImplTest {

    @Mock
    private TripRepository tripRepository;

    @InjectMocks
    private TripServiceImpl tripService;

    private Trip mockTrip;

    @BeforeEach
    void setUp() {
        mockTrip = Trip.builder()
                .id(1L)
                .departure("Ha Noi")
                .destination("Da Nang")
                .ticketPrice(500000.0)
                .availableSeats(20)
                .build();
    }

    @Test
    void getTripById_WhenTripExists_ShouldReturnTrip() {
        when(tripRepository.findById(1L)).thenReturn(Optional.of(mockTrip));

        Trip result = tripService.getTripById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Ha Noi", result.getDeparture());
        assertEquals("Da Nang", result.getDestination());
        assertEquals(500000.0, result.getTicketPrice());
        assertEquals(20, result.getAvailableSeats());
        verify(tripRepository, times(1)).findById(1L);
    }

    @Test
    void getTripById_WhenTripNotFound_ShouldThrowTripNotFoundException() {
        when(tripRepository.findById(999L)).thenReturn(Optional.empty());

        assertThrows(TripNotFoundException.class, () -> tripService.getTripById(999L));
        verify(tripRepository, times(1)).findById(999L);
    }

    @Test
    void verifyCacheableAnnotation_ShouldMatchRequirements() throws NoSuchMethodException {
        Method method = TripServiceImpl.class.getMethod("getTripById", Long.class);
        Cacheable cacheable = method.getAnnotation(Cacheable.class);

        assertNotNull(cacheable);
        assertArrayEquals(new String[]{"trips"}, cacheable.value());
        assertEquals("#id", cacheable.key());
        assertTrue(cacheable.sync());
    }
}
