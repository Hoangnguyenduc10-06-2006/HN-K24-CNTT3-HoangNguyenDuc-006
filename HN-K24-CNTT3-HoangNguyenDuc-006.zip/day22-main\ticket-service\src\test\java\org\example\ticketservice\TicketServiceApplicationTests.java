package org.example.ticketservice;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Disabled("Integration test requires running MySQL, Eureka, and Kafka instances")
@SpringBootTest
class TicketServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
