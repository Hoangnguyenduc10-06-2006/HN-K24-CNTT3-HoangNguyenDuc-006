package org.example.tripservice;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Disabled("Integration test requires running MySQL and Redis instances")
@SpringBootTest
class TripServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
