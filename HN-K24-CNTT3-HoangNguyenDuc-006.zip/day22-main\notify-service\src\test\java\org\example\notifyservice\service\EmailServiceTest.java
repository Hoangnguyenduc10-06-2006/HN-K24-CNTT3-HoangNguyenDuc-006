package org.example.notifyservice.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmailServiceTest {

    @Mock
    private JavaMailSender mailSender;

    private EmailService emailService;

    @BeforeEach
    void setUp() {
        emailService = new EmailService(mailSender, "noreply@ticket.com");
    }

    @Test
    void sendOrderCreatedEmail_WhenValidRecipient_ShouldSendEmail() {
        emailService.sendOrderCreatedEmail("user@test.com");

        ArgumentCaptor<SimpleMailMessage> messageCaptor = ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender, times(1)).send(messageCaptor.capture());

        SimpleMailMessage sent = messageCaptor.getValue();
        assertNotNull(sent);
        assertEquals("noreply@ticket.com", sent.getFrom());
        assertArrayEquals(new String[]{"user@test.com"}, sent.getTo());
        assertEquals("Order Created", sent.getSubject());
        assertEquals("Your order has been created successfully.", sent.getText());
    }

    @Test
    void sendOrderCreatedEmail_WhenNullRecipient_ShouldThrowIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> emailService.sendOrderCreatedEmail(null));
        verifyNoInteractions(mailSender);
    }

    @Test
    void sendOrderCreatedEmail_WhenEmptyRecipient_ShouldThrowIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> emailService.sendOrderCreatedEmail("   "));
        verifyNoInteractions(mailSender);
    }

    @Test
    void sendOrderCreatedEmail_WhenMailSenderNull_ShouldThrowUnsupportedOperationException() {
        EmailService noSenderService = new EmailService(null, "noreply@test.com");
        assertThrows(UnsupportedOperationException.class, () -> noSenderService.sendOrderCreatedEmail("user@test.com"));
    }
}
