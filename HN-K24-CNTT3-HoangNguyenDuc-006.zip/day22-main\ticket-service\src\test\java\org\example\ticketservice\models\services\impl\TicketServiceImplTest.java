package org.example.ticketservice.models.services.impl;

import org.example.ticketservice.exceptions.TripNotFoundException;
import org.example.ticketservice.models.constants.TicketStatus;
import org.example.ticketservice.models.dto.requests.CreateTicketDetailRequest;
import org.example.ticketservice.models.dto.requests.CreateTicketRequest;
import org.example.ticketservice.models.dto.responses.TicketResponse;
import org.example.ticketservice.models.dto.responses.TripResponse;
import org.example.ticketservice.models.entities.Ticket;
import org.example.ticketservice.models.entities.TicketDetail;
import org.example.ticketservice.models.repositories.TicketDetailRepository;
import org.example.ticketservice.models.repositories.TicketRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketServiceImplTest {

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private TicketDetailRepository ticketDetailRepository;

    @Mock
    private TripGatewayService tripGatewayService;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @InjectMocks
    private TicketServiceImpl ticketService;

    private CreateTicketRequest validRequest;
    private TripResponse mockTrip;

    @BeforeEach
    void setUp() {
        CreateTicketDetailRequest item = new CreateTicketDetailRequest(1L, 2);
        validRequest = new CreateTicketRequest("Nguyen Van A", "test@example.com", List.of(item));
        mockTrip = new TripResponse(1L, "Ha Noi", "Da Nang", 200000.0, 10);
    }

    @Test
    void createTicket_WhenValidRequest_ShouldCalculateCorrectlyAndSaveAndSendKafka() {
        when(tripGatewayService.getTripById(1L)).thenReturn(mockTrip);

        when(ticketRepository.save(any(Ticket.class))).thenAnswer(invocation -> {
            Ticket t = invocation.getArgument(0);
            t.setId(100L);
            return t;
        });

        when(ticketDetailRepository.saveAll(anyList())).thenAnswer(invocation -> {
            List<TicketDetail> list = invocation.getArgument(0);
            long idGen = 200L;
            for (TicketDetail d : list) {
                d.setId(idGen++);
            }
            return list;
        });

        TicketResponse response = ticketService.createTicket(validRequest);

        assertNotNull(response);
        assertEquals(100L, response.id());
        assertEquals("Nguyen Van A", response.passengerName());
        assertEquals("test@example.com", response.passengerEmail());
        assertEquals(400000.0, response.totalAmount());
        assertEquals(TicketStatus.PENDING, response.status());

        assertEquals(1, response.details().size());
        assertEquals(1L, response.details().get(0).tripId());
        assertEquals(2, response.details().get(0).seats());
        assertEquals(200000.0, response.details().get(0).ticketPrice());
        assertEquals(400000.0, response.details().get(0).lineTotal());

        verify(kafkaTemplate, times(1)).send("ticket-created", "test@example.com");
    }

    @Test
    void createTicket_WhenTripNotFound_ShouldPropagateExceptionAndNotSaveNorPublish() {
        when(tripGatewayService.getTripById(1L)).thenThrow(new TripNotFoundException(1L));

        assertThrows(TripNotFoundException.class, () -> ticketService.createTicket(validRequest));

        verify(ticketRepository, never()).save(any());
        verify(ticketDetailRepository, never()).saveAll(any());
        verify(kafkaTemplate, never()).send(anyString(), anyString());
    }

    @Test
    void createTicket_WhenSeatsExceedAvailableSeats_ShouldThrowIllegalArgumentException() {
        TripResponse lowSeatsTrip = new TripResponse(1L, "Ha Noi", "Da Nang", 200000.0, 1);
        when(tripGatewayService.getTripById(1L)).thenReturn(lowSeatsTrip);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> ticketService.createTicket(validRequest));

        assertTrue(ex.getMessage().contains("Not enough available seats"));
        verify(ticketRepository, never()).save(any());
        verify(kafkaTemplate, never()).send(anyString(), anyString());
    }

    @Test
    void createTicket_WhenSeatsIsZeroOrNegative_ShouldThrowIllegalArgumentException() {
        CreateTicketDetailRequest invalidItem = new CreateTicketDetailRequest(1L, 0);
        CreateTicketRequest req = new CreateTicketRequest("A", "a@a.com", List.of(invalidItem));

        assertThrows(IllegalArgumentException.class, () -> ticketService.createTicket(req));
        verify(ticketRepository, never()).save(any());
    }

    @Test
    void createTicket_WhenItemsEmpty_ShouldThrowIllegalArgumentException() {
        CreateTicketRequest req = new CreateTicketRequest("A", "a@a.com", Collections.emptyList());

        assertThrows(IllegalArgumentException.class, () -> ticketService.createTicket(req));
    }

    @Test
    void getTicketId_WhenExists_ShouldReturnId() {
        Ticket ticket = Ticket.builder().id(55L).build();
        when(ticketRepository.findById(55L)).thenReturn(Optional.of(ticket));

        Long id = ticketService.getTicketId(55L);
        assertEquals(55L, id);
    }
}
