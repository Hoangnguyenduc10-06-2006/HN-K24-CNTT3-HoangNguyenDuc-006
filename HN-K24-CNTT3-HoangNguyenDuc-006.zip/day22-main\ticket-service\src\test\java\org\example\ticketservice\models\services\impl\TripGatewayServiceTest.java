package org.example.ticketservice.models.services.impl;

import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.example.ticketservice.clients.TripClient;
import org.example.ticketservice.exceptions.TripNotFoundException;
import org.example.ticketservice.exceptions.TripServiceException;
import org.example.ticketservice.models.dto.responses.TripResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TripGatewayServiceTest {

    @Mock
    private TripClient tripClient;

    @InjectMocks
    private TripGatewayService tripGatewayService;

    private TripResponse mockTripResponse;

    @BeforeEach
    void setUp() {
        mockTripResponse = new TripResponse(1L, "Ha Noi", "Da Nang", 500000.0, 20);
    }

    @Test
    void getTripById_WhenSuccess_ShouldReturnTripResponse() {
        when(tripClient.getTripById(1L)).thenReturn(mockTripResponse);

        TripResponse result = tripGatewayService.getTripById(1L);

        assertNotNull(result);
        assertEquals(1L, result.id());
        assertEquals(500000.0, result.ticketPrice());
        assertEquals(20, result.availableSeats());
        verify(tripClient, times(1)).getTripById(1L);
    }

    @Test
    void getTripById_WhenClientReturnsNull_ShouldThrowTripNotFoundException() {
        when(tripClient.getTripById(1L)).thenReturn(null);

        assertThrows(TripNotFoundException.class, () -> tripGatewayService.getTripById(1L));
    }

    @Test
    void getTripById_WhenFeignNotFound_ShouldThrowTripNotFoundException() {
        Request request = Request.create(Request.HttpMethod.GET, "/api/v1/trips/1", Collections.emptyMap(), null, new RequestTemplate());
        FeignException.NotFound notFoundEx = new FeignException.NotFound("Not Found", request, null, Collections.emptyMap());
        when(tripClient.getTripById(1L)).thenThrow(notFoundEx);

        assertThrows(TripNotFoundException.class, () -> tripGatewayService.getTripById(1L));
    }

    @Test
    void getTripByIdFallback_WhenTripNotFoundException_ShouldRethrow() {
        TripNotFoundException ex = new TripNotFoundException(1L);

        TripNotFoundException thrown = assertThrows(TripNotFoundException.class,
                () -> tripGatewayService.getTripByIdFallback(1L, ex));
        assertEquals(ex.getMessage(), thrown.getMessage());
    }

    @Test
    void getTripByIdFallback_WhenFeignNotFound_ShouldThrowTripNotFoundException() {
        Request request = Request.create(Request.HttpMethod.GET, "/api/v1/trips/1", Collections.emptyMap(), null, new RequestTemplate());
        FeignException.NotFound notFoundEx = new FeignException.NotFound("Not Found", request, null, Collections.emptyMap());

        assertThrows(TripNotFoundException.class,
                () -> tripGatewayService.getTripByIdFallback(1L, notFoundEx));
    }

    @Test
    void getTripByIdFallback_WhenOtherException_ShouldThrowTripServiceException() {
        RuntimeException ex = new RuntimeException("Service down");

        TripServiceException thrown = assertThrows(TripServiceException.class,
                () -> tripGatewayService.getTripByIdFallback(1L, ex));
        assertTrue(thrown.getMessage().contains("unavailable"));
    }

    @Test
    void verifyCircuitBreakerAnnotation() throws NoSuchMethodException {
        Method method = TripGatewayService.class.getMethod("getTripById", Long.class);
        CircuitBreaker cb = method.getAnnotation(CircuitBreaker.class);

        assertNotNull(cb, "Method must have @CircuitBreaker");
        assertEquals("tripService", cb.name(), "CircuitBreaker name must be 'tripService'");
        assertEquals("getTripByIdFallback", cb.fallbackMethod(), "Fallback method name must be 'getTripByIdFallback'");
    }
}
